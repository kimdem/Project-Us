require("dotenv").config();
const express = require("express");
const app = express();
const cors = require("cors");
const http = require("http");
const server = http.createServer(app);
const {Server} = require("socket.io");
const db = require("./db");
const userRoutes = require("./userRoutes"); 
const chatRoutes = require("./chatRoutes");

app.use(cors());
app.use(express.json());

app.use("/api/users", userRoutes);
app.use("/api/chat", chatRoutes);

const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"],
  },
});

io.on("connection", (socket) => {
  console.log("클라이언트 연결:", socket.id);

  socket.on("joinRoom", (room_id) => {
    socket.join(room_id);
  });

  socket.on("sendMessage", async (data) => {
    const { room_id, user_id, message } = data;
    try {
      await db.query("INSERT INTO chat_message (room_id, user_id, message) VALUES (?, ?, ?)", [room_id, user_id, message]);
      io.to(room_id).emit("receiveMessage", {
        user_id,
        message,
        message_time: new Date()
      });
    } catch (err) {
      console.error("메시지 저장 오류:", err);
    }
  });

  socket.on("disconnect", () => {
    console.log("사용자 퇴장:", socket.id);
  });
});


server.listen(5000, () => {
  console.log("서버 구동 성공");
});
