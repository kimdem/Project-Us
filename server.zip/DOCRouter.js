const express = require("express");
const router = express.Router();
const db = require("./db");

router.post("/create-doc", async (req, res) => {
    const { doc_name, doc_password, doc_des, doc_admin } = req.body;

    if (!doc_name || !doc_password || !doc_des || !doc_admin) {
        return res.status(400).json({ message: "유효성 검사 필요" });
    }

    try {
        const sql = "INSERT INTO DOC (DOC_name, DOC_password, des, DOC_admin) VALUES (?, ?, ?, ?)";
        const [result] = await db.execute(sql, [doc_name, doc_password, doc_des, doc_admin]);
        const docId = result.insertId;
        const sql2 = "INSERT INTO DOC_members (DOC_id, user_id) VALUES (?, ?)";
        const [result2] = await db.execute(sql2, [docId, doc_admin]);
        return res.status(201).json({ message: "문서 방 생성 완료"});
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "서버 오류" });
    }
});

module.exports = router;