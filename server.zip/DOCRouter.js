const express = require("express");
const router = express.Router();
const db = require("./db");

router.post("/create-doc", async (req, res) => {
    const { doc_name, doc_password, doc_des, doc_admin } = req.body;

    if (!doc_name || !doc_password || !doc_admin) {
        return res.status(400).json({ message: "유효성 검사 필요" });
    }

    try {
        const sql = "INSERT INTO DOC (DOC_name, DOC_password, des, DOC_admin) VALUES (?, ?, ?, ?)";
        const [result] = await db.execute(sql, [doc_name, doc_password, doc_des, doc_admin]);
        const docId = result.insertId;
        const sql2 = "INSERT INTO DOC_members (DOC_id, user_id) VALUES (?, ?)";
        await db.execute(sql2, [docId, doc_admin]);
        return res.status(201).json({ message: "문서 방 생성 완료"});
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "서버 오류" });
    }
});

router.post("/enter-doc", async (req, res) => {
    const { doc_id, doc_password, user_id } = req.body;
    if (!doc_id || !doc_password || !user_id) {
        return res.status(400).json({ message: "유효성 검사 필요" });
    }
    try {
        const sql = "SELECT * FROM DOC WHERE DOC_id = ? AND DOC_password = ?";
        const [doc] = await db.execute(sql, [doc_id, doc_password]);
        if (doc.length === 0) {
            return res.status(404).json({ message: "문서 방을 찾을 수 없습니다." });
        }
        if (doc[0].DOC_password !== doc_password) {
            return res.json({ success: false, message: "비밀번호가 틀렸습니다." });
        }
        const [existing] = await db.execute("SELECT * FROM DOC_members WHERE DOC_id = ? AND user_id = ?", [doc_id, user_id]);
        if (existing.length > 0) {
            return res.status(400).json({ message: "이미 참가한 문서 방입니다." });
        }
        const sql2 = "INSERT INTO DOC_members (DOC_id, user_id) VALUES (?, ?)";
        await db.execute(sql2, [doc_id, user_id]);
        return res.status(200).json({ success: true, message: "문서 방에 참가했습니다." });
    } catch (error) {
        console.error(error);
        return res.status(500).json({ message: "서버 오류" });
    }
});

module.exports = router;